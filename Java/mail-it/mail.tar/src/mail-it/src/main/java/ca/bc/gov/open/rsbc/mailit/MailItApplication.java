package ca.bc.gov.open.rsbc.mailit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MailItApplication {

	public static void main(String[] args) {
		SpringApplication.run(MailItApplication.class, args);
	}

}

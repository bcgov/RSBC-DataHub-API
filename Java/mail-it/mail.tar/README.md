# mail-it

A simple mail application (with attachment support)

## Run locally

```bash
docker-compose up
```

### Containers

#### mailhog (Fake) email service endpoint for development. 

A [mailhog](https://github.com/mailhog/MailHog) instance accessible at [http://localhost:8025/](http://localhost:8025/)

